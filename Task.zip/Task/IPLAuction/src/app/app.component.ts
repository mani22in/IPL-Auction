import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  selectedPlayers = [];
  totalBudget = 1000000;

  // players details JSON
  playersDetails = [
    {
    'id': 1,
    'price': 100000,
    'battingRank': '1',
    'bowlingRank': '30',
    'allroundRank': '20'
    },
    {
    'id': 2,
    'price': 90000,
    'battingRank': '2',
    'bowlingRank': '23',
    'allroundRank': '24'
    },
    {
    'id': 3,
    'price': 55000,
    'battingRank': '3',
    'bowlingRank': '32',
    'allroundRank': '30'
    },
    {
    'id': 4,
    'price': 25000,
    'battingRank': '17',
    'bowlingRank': '21',
    'allroundRank': '38'
    },
    {
    'id': 5,
    'price': 150000,
    'battingRank': '6',
    'bowlingRank': '15',
    'allroundRank': '1'
    },
    {
    'id': 6,
    'price': 75000,
    'battingRank': '40',
    'bowlingRank': '12',
    'allroundRank': '33'
    },
    {
    'id': 7,
    'price': 80000,
    'battingRank': '19',
    'bowlingRank': '29',
    'allroundRank': '29'
    },
    {
    'id': 8,
    'price': 45000,
    'battingRank': '31',
    'bowlingRank': '34',
    'allroundRank': '30'
    },
    {
    'id': 9,
    'price': 90000,
    'battingRank': '29',
    'bowlingRank': '19',
    'allroundRank': '36'
    },
    {
    'id': 10,
    'price': 62592,
    'battingRank': '22',
    'bowlingRank': '56',
    'allroundRank': '88'
    },
    {
    'id': 11,
    'price': 61456,
    'battingRank': '65',
    'bowlingRank': '85',
    'allroundRank': '44'
    },
    {
    'id': 12,
    'price': 95196,
    'battingRank': '55',
    'bowlingRank': '65',
    'allroundRank': '77'
    },
    {
    'id': 13,
    'price': 65466,
    'battingRank': '56',
    'bowlingRank': '54',
    'allroundRank': '57'
    },
    {
    'id': 14,
    'price': 56988,
    'battingRank': '22',
    'bowlingRank': '52',
    'allroundRank': '12'
    },
    {
    'id': 15,
    'price': 84852,
    'battingRank': '58',
    'bowlingRank': '14',
    'allroundRank': '22'
    },
    {
    'id': 16,
    'price': 94984,
    'battingRank': '78',
    'bowlingRank': '51',
    'allroundRank': '93'
    },
    {
    'id': 17,
    'price': 84841,
    'battingRank': '78',
    'bowlingRank': '32',
    'allroundRank': '44'
    },
    {
    'id': 18,
    'price': 98489,
    'battingRank': '45',
    'bowlingRank': '65',
    'allroundRank': '49'
    },
    {
    'id': 19,
    'price': 151465,
    'battingRank': '11',
    'bowlingRank': '3',
    'allroundRank': '9'
    },
    {
    'id': 20,
    'price': 65265,
    'battingRank': '44',
    'bowlingRank': '63',
    'allroundRank': '25'
    }
  ];

  selectedBudget = 0;
  availableBudget = this.totalBudget;
  Strength;

  // select player
  selectPlayer(player) {
    if (this.selectedPlayers.length >= 1) {
      for (let i = 0; i < this.selectedPlayers.length; i++) {
           if (this.selectedPlayers[i] === player) {
              alert('Oops! The Player already in your selected list');
              return;
           }
        }
    }
    if (this.selectedBudget + player.price > this.totalBudget) {
      alert('Oops! your Budget Exceed the Limit');
        return;
    } else {
      this.selectedBudget = this.selectedBudget + player.price;
      this.selectedPlayers.push(player);
      this.availableBudget = this.totalBudget - this.selectedBudget;
      this.strength();
    }
  }
  // Remove Player from selected list
  removePlayer(player) {
    for (let i = 0; i < this.selectedPlayers.length; i++) {
      if (this.selectedPlayers[i] === player) {
        this.selectedBudget = this.selectedBudget - player.price;
        this.availableBudget = this.totalBudget - this.selectedBudget;
        this.selectedPlayers.splice(i , 1);
        this.strength();
         alert('Removed Successfully!!!');
         return;
      }
   }
  }

  // strength calculating
  strength() {
    let indStrength = 0;
    if (this.selectedPlayers.length === 0) {
      this.Strength = 0;
      return;
    }
    for (let i = 0; i < this.selectedPlayers.length; i++) {
      indStrength = indStrength + (100 - this.selectedPlayers[i].battingRank +
        100 - this.selectedPlayers[i].bowlingRank +
        100 - this.selectedPlayers[i].allroundRank);
        if (i === (this.selectedPlayers.length - 1)) {
          this.Strength = (indStrength) / (this.selectedPlayers.length * 3);
        }
    }

  }

}
